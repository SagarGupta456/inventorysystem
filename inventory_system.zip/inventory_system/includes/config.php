<?php
/*
|--------------------------------------------------------------------------
| US Technologies Inventory Management System V2
|--------------------------------------------------------------------------
| Author: Saeed Nawaz
| Project Name: USTech-IMS
| Version: v2
| Support page: http://ustechlogix.net/
|
|
|
*/
  define( 'DB_HOST', 'localhost' );          // Set database host
  define( 'DB_USER', 'root' );             // Set database user
  define( 'DB_PASS', '' );             // Set database password
  define( 'DB_NAME', 'inventory' );        // Set database name

?>
